from os import write
from re import I
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
import requests
import urllib3
import csv
import sys
import time
import random
urllib3.disable_warnings()

URL="https://search.books.com.tw/search/query/key/{}/cat/all"
def generate_url_serch(URL,key1):
    urlx=[]
    urlx.append(URL.format(key1)) #先做好爬多頁的準備
    return urlx
    

def get_res(url):
    UA=UserAgent()  #設定user-agent
    headers={
        "user-agent":UA.random
    }
    res=requests.get(url,headers=headers)
    return res


def parse(html_str):
    return BeautifulSoup(html_str,"lxml")#在這邊放進湯 我沒有回傳text格式，所以套入函式時需要.text


def get_word(soup):
    words=[]
    #count=0
    for get_0 in soup.find_all(class_='table-searchlist clearfix'):
            #print(type(get_0)) === <class 'bs4.element.Tag'>
            for get_1 in get_0.find_all("td"):#前面兩次td沒有h4跟li且我在底下設空list，會導致一直加空list->append->list
                newwords=[]#用於分隔每筆書的資料
                for get_2 in get_1.find_all("h4"):#這是抓標題
                    testURL=get_2.find("a")["href"]#抓ISBN用的網址，在h4下面
                    PAI=get_ISBN_Price(testURL)
                    sL=random.randint(30,50)#睡眠時間設隨機且秒數長，為了更像人
                    print("sleep {} S".format(sL))
                    time.sleep(sL)
                    #time.sleep(10) #方便測試用
                    newwords.append(PAI)
                    newwords.append(get_2.text.replace("\n",""))
                for get_3 in get_1.find_all("li"):
                    newwords.append(get_3.text.replace("\n",""))
                if newwords!=[]: #由於在抓資料時，會有前面的td沒有包含我要抓的元素，又因為我在td下面宣告空的陣列(用於把每本書的資料分開)，
                    words.append(newwords)#沒有設if會把空的字串append進去，導致前面兩次td是抓空的(也會導致是空的不進入迴圈)，第三次才正式抓到h4跟li的迴圈
                print(words)    #觀察list用
                #print(newwords)#觀察list用
    return words

def get_ISBN_Price(url):
    url1="https:"+url
    print(url1)
    soup = parse(get_res(url1).text)#丟進湯 流程: 先取得request -> 再丟進湯中  ***加上.text才能丟進去parse***
    l=int()
    for get_bd in soup.find_all(class_="bd"):
        #print(get_bd) 我用於檢查 抓的資料 經過測試 也許是抓取速度太快 以至於抓不到資料
        for get_ISBN in get_bd.find_all("li"):
            #print(get_ISBN) 同上 我一層一層檢查的
            if 'ISBN' in get_ISBN.text:  #因為bd的li當中有其他資料，故用if挑選出有ISBN                  result
                b_ISBN=get_ISBN.text[5:] #ISBN: 五個 或是0 1 2 3 4 之後的都印出來  ||ex:ISBN:20201111    ------> 20201111||
                return int(b_ISBN)              
            else:#由於怕沒抓到的狀況 我再加一個沒抓到的情況 回傳值
                #否則，會回傳一個沒宣告的變數，也就是還沒宣告前不能回傳
                return
            

    


def scraping(urls):
    Nword=[]
    print(urls)
    r=get_res(urls[0])#因為要get字串 所以指定list裡面的第一個
    if r.status_code==requests.codes.ok:
        soup=parse(r.text)        
        word=get_word(soup)
        Nword=Nword+word 
    else:
        print("ERROR")
    
    return Nword

def save_to_file(eng_word,file):
    with open(file,"w+",newline="",encoding="utf8")as fp:
        writer = csv.writer(fp)
        for word in eng_word:
            writer.writerow(word)
    return writer



if __name__=="__main__": #怕之後被套用函式會執行這串，所以限定在程式本身執行(__main__)
    if len(sys.argv)>1:#確保輸入正確
        url =  generate_url_serch(URL,sys.argv[1])
        eng=scraping(url)
        print(*eng, sep='\n')
        save_to_file(eng,'project.csv')
    

    
