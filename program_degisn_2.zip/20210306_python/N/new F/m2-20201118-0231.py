n=int(input())
for i in range(1,n+1):
    if n%i==0:  #如果n/i為整除 輸出i   因為i可以整除n  為n的正因數
        print(i)


        #M2 Q11 正因數