n=int(input())
x=0
for i in range(1,n+1):
    if i%3==0:
        x=x+i
print(x)

    