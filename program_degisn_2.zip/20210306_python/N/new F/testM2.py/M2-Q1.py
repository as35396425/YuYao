lst=[float(num)for i in range (5) for num in input().split("\n")]
print("max=%.2f"%max(lst))
print("mix=%.2f"%min(lst))
