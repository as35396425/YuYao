n=int(input())
STR1=''
while n>0:
    print("{}".format(n%10),end='')
    n=n//10
print