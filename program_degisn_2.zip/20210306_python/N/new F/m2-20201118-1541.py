n=int(input())
x=1
for i in range (n):
    x=x+i
    
    print(x,end='  ')
    print
    