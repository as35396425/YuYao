for i in range (1,4):
    print(i)