n=int(input())
y=0
for i in range(1,n+1):
    x=i*(i+1)
    y=y+x

print(y)

#Q14 n*(n+1)總和
