from selenium import webdriver #引用webdriver
driver = webdriver.Chrome('chromedriver.exe') #啟動webdriver
driver.get('https://www.google.com') #前往指定網頁