n=int(input())
y=0
for i in range (1,n+1):
    x=1/((2*i-1)*(2*i))
    y=y+x  #利用for迴圈 累加

print(y)


#Q15-M2 1/[(2n-1)*(2n)]總和