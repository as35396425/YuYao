n=int(input())
x=1
for i in range(n,1,-1):
    x=x*i
    
print(x)