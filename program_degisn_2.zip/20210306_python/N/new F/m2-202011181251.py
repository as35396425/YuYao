n=int(input())
y=0
for i in range (1,n+1):
    x=2**i
    y=y+x

print(y)