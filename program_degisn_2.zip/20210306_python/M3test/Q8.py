data=list(map(int,input().split()))

for i in data:
    print("{}\t".format(i**2),end="")
