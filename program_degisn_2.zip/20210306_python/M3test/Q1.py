data=list(input())

data=reversed(data)


for i in data:
    print(i,end="")
print()

