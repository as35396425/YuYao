x=input()
y=reversed(list(x))
if list(x)==list(y):
    print('yes')
else:
    print("NO")