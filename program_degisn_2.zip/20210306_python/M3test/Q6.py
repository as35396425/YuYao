
data=list(input())

for i in data:
    print('{} '.format(i),end="")
print()